#!/usr/bin/env python

###########################################################################################
#
#             override views module, to:
# 1) requere login
# 2) get the user name provided by the user, at the login page
# fit it to the tasks assign by the admin
# redirect to display those to the user.
#
###########################################################################################

from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from manage import *
from models import *
from sql import *
import json
import os
from .forms import UploadFileForm
from django import forms
from django.contrib.auth.decorators import login_required

regax = [str(i) for i in range(10)]       # for taking appart the targetDate and the name of the assignment.
path = os.getcwd()

@login_required
def home(request):
    return HttpResponseRedirect(
               reverse(NAME_OF_PROFILE_VIEW, 
                       args=[request.user.username]))   # simple login wrapper (not being used, cuz i wrote it in the html)
                                                        # redirection at the javascript tab.. but its here for continuation..
# the index function handles the request from the user exctracting the username
# inserted by the previe's form submit, strips the db of its data, chacks if the name is
# in the tasks assign by the admin, and wrap's the res code with nice bootstrap html.
def index(request):               
    boolien = 0                               # to chack if we are at the tasks.
    profile = request.user.username           # to get the username
    jsonList = []                             # to return to the wrapper
    parsedData = []                           # return value
    plain = getter()                          # use the sql getter function to get the data.
    args = plain.split('\n')
    for item in args:
	 if "id                 name worker targetDate" in item:   
               boolien += 1
	 elif    '0   1         admin     logentry' in item:
	       boolien -= 1
         if profile in item and (1 == boolien):
                print(item)
                task_data = {}
		argv = item.strip('  ').split(' ')
		nm = ''
		td = ''
		for var in argv:                         # striping and getting the arguments.
                     if var != '':                       # note that if the assignment is not at the
                         try:                            # type:
			     int(var)                    # name: mostly string longer then 3 charecters
                         except:                         # targetDate: mostly numbers.
                             if len(var) <= 2 or profile in var:  # then i dont think that the function will work.
                                 continue
                             counter = 0
                             for num in regax:
                                 counter += 1
                             if counter <= 3:
                                   nm += var + ' '
			     else:
				   if not 'app_label' in var and not 'model' in var:
				         td += var + ' '

                task_data['name'] = nm
                task_data['targetDate'] = td
	 	parsedData.append(task_data)
    return render(request, path +'/app/templates/task.html', {'data': parsedData})   # wrapps around and return's.








