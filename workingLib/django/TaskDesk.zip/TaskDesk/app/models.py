from manage import *
from sqlutils import *
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth import logout
from django.http import HttpResponseRedirect
import os, subprocess


class Task(models.Model):
    name = models.CharField(max_length=30)
    worker = models.CharField(max_length=30)
    targetDate = models.CharField(max_length=30)

    def __str__(self):              
        return self.name

class SubmitFile(models.Model):
	f = models.CharField(max_length=100)
	
	def __str__(self):              
        	return self.f
	

@receiver(post_save, sender=SubmitFile, dispatch_uid="update_file")
def update_stock(sender, instance, **kwargs):
	path = instance.__str__()
	# argv = read_tasks(path)
	proc = subprocess.Popen(['python', os.getcwd()+'/app/sqlutils.py',path])
	return HttpResponseRedirect("http://127.0.0.1:8000")
	# utils = SQLUtils(argv)
	# utils.update_db()

	













