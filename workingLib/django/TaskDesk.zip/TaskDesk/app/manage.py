#!/usr/bin/env python

##########################################################################################################
# 
#   an helper module for the models.py, contains a class for handling tasks logging.
#
##########################################################################################################

import sqlite3, os # import sqlite3 for the connection to the db, and os to get the system current working directory.

path = os.getcwd()
data_base_tasks = path + '/TaskDesk/tasks'           


# an helper class for the module's.py not used at the moment it can be used for adding some
# extra functionality's later on.

class BaseTask:

	def __init__(self,args):
		self._information = {}
		self._information['name'] = args[0]
		self._information['targetDate'] = args[1]           
		self._information['worker'] = args[2]           # i had to add 'worker' field to the class
		                                                # for later using it for matching the users request to the
								# tasks assigned by the admin.

	def repr(self):
		return repr(self._information)                 # repr method
	
	def content(self):
		return self._information                       # return the actual content.
	
	def register(self):
		conn = sqlite3.connect(path +'/TaskDesk/db.sqlite3')  # register at the db (being done automaticlly) so its not used.
		c = conn.cursor()
		try:
			c.execute('''CREATE TABLE tasks
             				(name text, targetDate text)''')
		except sqlite3.OperationalError as e:
			pass
		c.execute("INSERT INTO tasks VALUES ('"+str(self._information['name'])+"','"+
			str(self._information['worker'])+"','"+str(self._information['targetDate'])+"')")
		conn.commit()
		conn.close()
	
	def reg(self):
		with open(data_base_tasks, mode='w') as db:   # register at a plain text file.
			db.write(self.repr())



# writing workers module was not needed i used the 'users' built-in...





