import sqlite3, os, sys, time

path = os.getcwd()
path_ = os.getcwd().split('app')[0]

class SQLUtils:
	
	def __init__(self, data):
		self._data = data
	
	def update_db(self):
		sqlite_file = path_ + '/db.sqlite3'
		table_name = "app_task"
		id_column = 'name'
		column_name = 'worker'
		targetDate = 'targetDate'
		conn = sqlite3.connect(sqlite_file)
		c = conn.cursor()
		for args in self._data:
			argv = repr(tuple(args))
			# print argv
			execv = "INSERT INTO {tn} ({idf}, {cn}, {td}) VALUES "+argv
			# print execv
			try:
    				c.execute(execv.\
					format(tn=table_name, idf=id_column, cn=column_name, td=targetDate))
			except sqlite3.IntegrityError:
    				print('ERROR: ID already exists in PRIMARY KEY column {}'.format(id_column))
			conn.commit()
		conn.close()

def read_tasks(file_name):
	args = []
	with open(file_name, mode='r') as inf:
		data = inf.read().split("\n")
		for dat in data:
			arg = dat.split("\t")
			if len(arg) != 1:
				args.append(arg)
	return args

if __name__ == '__main__':
	time.sleep(3)
	path = sys.argv[1]
	argv = read_tasks(path)
	utils = SQLUtils(argv)
	utils.update_db()











