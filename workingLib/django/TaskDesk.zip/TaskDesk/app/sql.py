#!/usr/bin/env python

###########################################################################
#
#      an helper module for the views.py
#     drops the data base and return to the views.py
#
###########################################################################

import sqlite3, os
import pandas as pd
from manage import *

path = os.getcwd()
path_ = os.getcwd().split('app')[0]

def to_csv():
    db = sqlite3.connect(path_+'/db.sqlite3')   # convert the buffers stored at the db to csv
    cursor = db.cursor()                                  # then write it to a plain text
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    with open(path + '/tasks_.txt', mode='w') as plainText:
    	for table_name in tables:
        	table_name = table_name[0]
        	table = pd.read_sql_query("SELECT * from %s" % table_name, db)
                # print(repr(table))
        	plainText.write(repr(table))

def getter():
	to_csv() 
        r = ''                                         # call the to_csv, open to read the content, truncate and return. 
	with open(path +'/tasks_.txt', mode='r') as data:
		r = data.read()
	with open(path +'/tasks_.txt', mode='w') as data:
                data.truncate()
	return r

if __name__ == "__main__":
	getter()
