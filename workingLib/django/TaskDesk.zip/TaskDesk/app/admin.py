from django.contrib import admin
from .models import Task, SubmitFile

admin.site.register(Task)  # writing workers module was not needed i used the 'users' built-in...
admin.site.register(SubmitFile)

