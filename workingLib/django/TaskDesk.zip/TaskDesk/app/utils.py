#!/usr/bin/python

import sqlite3

conn = sqlite3.connect('/home/yt/workingLib/django/TaskDesk/db.sqlite3')
c = conn.cursor()
for row in c.execute('SELECT "name", "worker", "targetDate" FROM sqlite_master WHERE name="app_task";'):
        print(row)


