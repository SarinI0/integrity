from django import forms

class UploadFileForm(forms.Form):
    title = forms.CharField(max_length=50)
    file = forms.FileField()                           # i started to write the upload file functionallty
						       # but had no time to complete it...
